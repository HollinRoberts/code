# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import random
from django.shortcuts import render,redirect,HttpResponse

def index(request):
    print 'working'
    return render(request,'gold_app/index.html')
def index(request):
    output=''
    if "gold" not in request.session:
        gold=0
        request.session['gold']=gold
        print request.session['gold']
    if "action" not in request.session:    
        request.session['action']=[]
        request.session['action'].append("Welcome")
    return render(request,'gold_app/index.html')
def process(request):
    print request.POST
    print 'hey'
    print request.session['action']
    if 'farm' in request.POST:
        earnings=random.randrange(10,20)
        request.session['gold']=request.session['gold']+earnings
        request.session['action'].append('<p >You went to the farm and earned {0} gold</p>' .format (earnings))
    if "cave" in request.POST:
        earnings=random.randrange(5,10)
        request.session['gold']=request.session['gold']+earnings
        request.session['action'].append('<p >You went to the cave and earned {0} gold</p>' .format (earnings))
    if "house" in request.POST:
        earnings=random.randrange(2,5)
        request.session['gold']=request.session['gold']+earnings
        request.session['action'].append('<p >You went to the house and earned {0} gold</p>' .format (earnings))
    if "casino" in request.POST:
        gold=request.session['gold']
        if random.randint(0,1)==int(1):
            earnings=random.randrange(0,50)
            request.session['gold']=request.session['gold']+earnings
            request.session['action'].append('<p >You went to the casino and earned {0} gold</p>' .format (earnings))
        else:
            earnings=random.randrange(0,50)
            request.session['gold']=request.session['gold']-earnings
            request.session['action'].append('<p >You went to the casion and lost {0} gold</p>' .format (earnings))
    return redirect('/',)
# Create your views here.
#  request.session['action'].append('<p >You went to the farm and earned {1}</p>' .format (earnings)