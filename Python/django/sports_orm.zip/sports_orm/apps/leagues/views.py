from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	print League.objects.filter(sport="Hockey")
	context = {
		"leagues": League.objects.all(),
		"baseball_leagues": League.objects.filter(sport='Baseball'),
		"womens_leagues": League.objects.filter(name__contains="Womens"),
		"hockey_leagues": League.objects.filter(sport__contains='Hockey'),
		"not_football": League.objects.all().exclude(sport='Football'),
		"conference": League.objects.filter(name__contains='Conference'),
		"atlantic": League.objects.filter(name__contains='Atlantic'),
		"dallas": Team.objects.filter(location='Dallas'),
		"raptors": Team.objects.filter(team_name__contains='Raptors'),
		"City_Names": Team.objects.filter(location__contains='City'),
		"t_teams": Team.objects.filter(team_name__startswith='T'),
		"teams": Team.objects.all().order_by('location'),
		"teams_name": Team.objects.all().order_by('team_name').reverse(),
		"players_last": Player.objects.filter(last_name__contains='Cooper'),
		"players_first": Player.objects.filter(first_name__contains='Joshua'),
		"not_josh": Player.objects.filter(last_name__contains='Cooper').exclude(first_name__contains='Joshua'),
		"alexander_wyatt": Player.objects.filter(first_name__in=['Alexander',"Wyatt"]),
		"players": Player.objects.all(),
		"atlantic_teams": League.objects.get(name="Atlantic Soccer Conference").teams.all(),
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")