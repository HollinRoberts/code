// Import express and path modules.
var express = require( "express");
var path = require( "path");
// Create the express app.
var app = express();
// Define the static folder.
var bodyParser = require('body-parser');
// Integrate body-parser with our App
var mongoose = require("mongoose");
mongoose.connect('mongodb://localhost/basic_mongoose');
var QuoteSchema = new mongoose.Schema({
    quote:{type:String, required:true},
    name:{type:String, required:true},
},{timestamps:true});
mongoose.model('quote',QuoteSchema)
var Quote = mongoose.model('quote')

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "./static")));
// Setup ejs templating and define the views folder.
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
// Root route to render the index.ejs view.
app.get('/', function(req, res) {
    res.render("index");
})    

app.post('/quotes', function(req, res) {
    console.log("POST DATA", req.body);
    var quote = new Quote({name:req.body.name,quote:req.body.quote});
    quote.save(function(err){
        if(err){
            console.log("error")
            res.render('index',{title:'you have errors!', errors:quote.errors})
        } else {
            console.log("successfully added a quote");
            res.redirect("/quotes")
        }

    })
})
app.get('/quotes', function(req, res){
    Quote.find({},function(err,quotes){
        if(err){
            console.log("error")
        } else {
            console.log(quotes);
            var context={"quotes":quotes};
            res.render('quotes',context);
        }
    })
})
// Start Node server listening on port 8000.
var server = app.listen(8000, function() {
    console.log("listening on port 8000");
   });
