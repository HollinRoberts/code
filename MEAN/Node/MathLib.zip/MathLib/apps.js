var math= require('./mathlib')();
console.log(math.add(2,5))
console.log(math.multiply(2,5))
console.log(math.square(5))
console.log(math.random(5,50))